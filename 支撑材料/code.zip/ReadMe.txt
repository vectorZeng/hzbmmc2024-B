pro1-4.m为每一问的代码
plot-pro4是画问题四的十字路口
cluster_idx_12.mat 文件是问题四的K-maens聚类结果，由于K-means算法每次的效果都不太一样，这个文件所保留的是效果最好的
